API
====

.. user module

USER MODULE
------------

.. automodule:: webapp.module.user

.. autofunction:: github_login

.. autofunction:: github_login_callback

.. autofunction:: profile

.. kodo class

KODO
-----

.. automodule:: webapp.share.kodo

.. autoclass:: KodoClient
   :members:
